#ifndef __LIBRARIES_H__
#define __LIBRARIES_H__

#include <iostream>
#include <vector> 
#include <string>

using namespace std;

#define NOT_FOUND_YET -1
#define UNASSIGNED "Unassigned"

#endif